import boto3
import mysql.connector
import logging
import json

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# SSM client
ssm_client = boto3.client('ssm')

# Secrets Manager client
secrets_client = boto3.client('secretsmanager')

def lambda_handler(event, context):
    # Retrieve RDS host from Parameter Store
    try:
        rds_host = ssm_client.get_parameter(Name='/ccj/RDS/BillshockDBEndpoint')['Parameter']['Value']
    except Exception as e:
        logger.error(f"Error retrieving RDS host from Parameter Store: {e}")
        return {
            'statusCode': 500,
            'body': 'Error retrieving RDS host'
        }

    # Retrieve RDS password from Secrets Manager
    try:
        secret_response = secrets_client.get_secret_value(SecretId='ccj-billshock-db-secret')
        secret = json.loads(secret_response['SecretString'])
        rds_password = secret['password']
    except Exception as e:
        logger.error(f"Error retrieving RDS password from Secrets Manager: {e}")
        return {
            'statusCode': 500,
            'body': 'Error retrieving RDS password'
        }

    # AWS RDS connection details
    rds_user = "admin"
    rds_database = "billshock"

    try:
        # Connect to the RDS instance
        logger.info("Connecting to RDS instance...")
        conn = mysql.connector.connect(
            host=rds_host,
            user=rds_user,
            password=rds_password,
            db=rds_database,
            connect_timeout=5
        )

        with conn.cursor() as cur:
            # Drop existing table if it exists
            logger.info("Dropping existing table...")
            cur.execute("DROP TABLE IF EXISTS customer_bills_overview;")
            conn.commit()
            logger.info("Existing table dropped successfully.")

            # Create the 'customer_bills_overview' table
            create_table_query = """
                CREATE TABLE IF NOT EXISTS customer_bills_overview (
                    customer_mobile_number BIGINT NOT NULL,
                    customer_email VARCHAR(255),
                    customer_secret_key INT,
                    customer_dob DATE,
                    billing_month DATE NOT NULL,
                    data_usage_mb INT NOT NULL,
                    data_cost DECIMAL(10,2) NOT NULL,
                    roaming_data_usage_mb INT NOT NULL,
                    roaming_data_cost DECIMAL(10,2) NOT NULL,
                    call_duration INT NOT NULL,
                    call_cost DECIMAL(10,2) NOT NULL,
                    roaming_call_duration INT NOT NULL,
                    roaming_call_cost DECIMAL(10,2) NOT NULL,
                    total_amount DECIMAL(10,2) NOT NULL,
                    PRIMARY KEY (customer_mobile_number, billing_month)
                );
            """
            cur.execute(create_table_query)
            conn.commit()
            logger.info("Table 'customer_bills_overview' created successfully.")

    except mysql.connector.Error as e:
        logger.error(f"Error: {e}")
        return {
            'statusCode': 500,
            'body': f'Error connecting to or querying database: {str(e)}'
        }

    finally:
        # Close the connection
        if 'conn' in locals():
            conn.close()
            logger.info("Connection closed.")

    return {
        'statusCode': 200,
        'body': 'Lambda function executed successfully.'
    }