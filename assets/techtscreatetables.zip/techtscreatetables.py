import pymysql
import logging
import boto3
import json

# Set up logging to CloudWatch
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    try:
        # Get RDS host from Parameter Store
        ssm_client = boto3.client('ssm')
        rds_host = ssm_client.get_parameter(Name='/ccj/RDS/TechsupportDBEndpoint')['Parameter']['Value']

        # Get RDS password from Secrets Manager
        secrets_client = boto3.client('secretsmanager')
        secret_response = secrets_client.get_secret_value(SecretId='ccj-techsupport-db-secret')
        secret = json.loads(secret_response['SecretString'])
        rds_password = secret['password']

        rds_user = 'admin'
        rds_database = 'techsupport'

        # Connect to the RDS instance
        logger.info("Connecting to RDS instance...")
        conn = pymysql.connect(
            host=rds_host,
            user=rds_user,
            password=rds_password,
            connect_timeout=5
        )

        with conn.cursor() as cur:
            # Check if the database exists, if not create it
            cur.execute(f"CREATE DATABASE IF NOT EXISTS {rds_database}")
            conn.commit()
            logger.info(f"Database '{rds_database}' created or already exists.")

            # Switch to the techsupport database
            cur.execute(f"USE {rds_database}")
            conn.commit()

            # Drop existing tables if they exist
            logger.info("Dropping existing tables...")
            cur.execute("DROP TABLE IF EXISTS customerbillingdetails;")
            cur.execute("DROP TABLE IF EXISTS customercurrentmonth;")
            cur.execute("DROP TABLE IF EXISTS customermodemdetails;")
            cur.execute("DROP TABLE IF EXISTS nodedetails;")
            cur.execute("DROP TABLE IF EXISTS customerauth;")
            conn.commit()
            logger.info("Existing tables dropped successfully.")

            # Create the 'customerbillingdetails' table
            create_table_query = """
                CREATE TABLE customerbillingdetails (
                    customer_id BIGINT UNSIGNED NOT NULL,
                    secret_key INT UNSIGNED NOT NULL,
                    bill_month DATE NOT NULL,
                    service_plan VARCHAR(20) NOT NULL,
                    monthly_charge DECIMAL(10, 2) NOT NULL,
                    data_usage INT NOT NULL,
                    overage_charges DECIMAL(10, 2) NOT NULL,
                    taxes DECIMAL(10, 2) NOT NULL,
                    total_amount DECIMAL(10, 2) NOT NULL,
                    monthly_data_allowed_download INT NOT NULL,
                    monthly_data_allowed_upload INT NOT NULL,
                    allowed_upload_speed INT NOT NULL,
                    allowed_download_speed INT NOT NULL,
                    bill_paid BOOLEAN NOT NULL DEFAULT FALSE,
                    PRIMARY KEY (customer_id, bill_month)
                );
            """
            cur.execute(create_table_query)
            conn.commit()
            logger.info("Table 'customerbillingdetails' created successfully.")

            # Create the 'customercurrentmonth' table
            create_table_query = """
                CREATE TABLE customercurrentmonth (
                    customer_id BIGINT UNSIGNED NOT NULL,
                    current_month DATE NOT NULL,
                    secret_key INT UNSIGNED NOT NULL,
                    current_total_download INT NOT NULL,
                    current_total_upload INT NOT NULL,
                    monthly_data_allowed_download INT NOT NULL,
                    monthly_data_allowed_upload INT NOT NULL,
                    allowed_upload_speed INT NOT NULL,
                    allowed_download_speed INT NOT NULL,
                    new_upload_speed INT,
                    new_download_speed INT,
                    PRIMARY KEY (customer_id, current_month)
                );
            """
            cur.execute(create_table_query)
            conn.commit()
            logger.info("Table 'customercurrentmonth' created successfully.")

            # Create the 'customermodemdetails' table
            create_table_query = """
                CREATE TABLE customermodemdetails (
                    customer_id BIGINT UNSIGNED NOT NULL PRIMARY KEY,
                    node_id BIGINT UNSIGNED NOT NULL,
                    modem_serial_number BIGINT UNSIGNED NOT NULL,
                    modem_model VARCHAR(50) NOT NULL,
                    modem_manufacturer VARCHAR(50) NOT NULL,
                    modem_ip VARCHAR(11),
                    modem_firmware_version VARCHAR(20) NOT NULL,
                    modem_activation_date DATE NOT NULL,
                    modem_status BOOLEAN NOT NULL,
                    modem_notes TEXT
                );
            """
            cur.execute(create_table_query)
            conn.commit()
            logger.info("Table 'customermodemdetails' created successfully.")

            # Create the 'nodedetails' table
            create_table_query = """
                CREATE TABLE nodedetails (
                    node_id BIGINT UNSIGNED NOT NULL PRIMARY KEY,
                    node_name VARCHAR(50) NOT NULL,
                    node_location_city VARCHAR(100) NOT NULL,
                    node_location_state VARCHAR(2) NOT NULL,
                    node_location_zipcode CHAR(5) NOT NULL,
                    node_status BOOLEAN NOT NULL,
                    node_next_maintenance_date DATE
                );
            """
            cur.execute(create_table_query)
            conn.commit()
            logger.info("Table 'nodedetails' created successfully.")

            # Create the 'customerauth' table
            create_table_query = """
                CREATE TABLE customerauth (
                    customer_id BIGINT UNSIGNED NOT NULL PRIMARY KEY,
                    secret_key BIGINT UNSIGNED NOT NULL
                );
            """
            cur.execute(create_table_query)
            conn.commit()
            logger.info("Table 'customerauth' created successfully.")

            # List all databases
            cur.execute("SHOW DATABASES")
            databases = cur.fetchall()
            logger.info("List of all databases:")
            for db in databases:
                logger.info(db[0])

            # List all tables in the techsupport database
            cur.execute("SHOW TABLES")
            tables = cur.fetchall()
            logger.info(f"List of tables in the '{rds_database}' database:")
            for table in tables:
                logger.info(table[0])

        conn.close()

        return {
            'statusCode': 200,
            'body': 'Table creation successful, databases and tables listed in CloudWatch logs'
        }

    except Exception as e:
        logger.error(f"Error: {e}")
        return {
            'statusCode': 500,
            'body': 'Error occurred during table creation or listing'
        }