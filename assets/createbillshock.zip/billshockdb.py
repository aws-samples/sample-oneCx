import boto3
import mysql.connector
import logging
import json

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# SSM client
ssm_client = boto3.client('ssm')

# Secrets Manager client
secrets_client = boto3.client('secretsmanager')

def lambda_handler(event, context):
    # Retrieve RDS host from Parameter Store
    try:
        rds_host = ssm_client.get_parameter(Name='/ccj/RDS/BillshockDBEndpoint')['Parameter']['Value']
    except Exception as e:
        logger.error(f"Error retrieving RDS host from Parameter Store: {e}")
        return {
            'statusCode': 500,
            'body': 'Error retrieving RDS host'
        }

    # Retrieve RDS password from Secrets Manager
    try:
        secret_response = secrets_client.get_secret_value(SecretId='ccj-billshock-db-secret')
        secret = json.loads(secret_response['SecretString'])
        rds_password = secret['password']
    except Exception as e:
        logger.error(f"Error retrieving RDS password from Secrets Manager: {e}")
        return {
            'statusCode': 500,
            'body': 'Error retrieving RDS password'
        }

    # RDS MySQL connection details
    rds_user = "admin"
    rds_database = "billshock"
    rds_port = 3306  # Default MySQL port, change if you're using a different port

    try:
        # Connect to the RDS MySQL instance
        conn = mysql.connector.connect(
            host=rds_host,
            user=rds_user,
            password=rds_password,
            port=rds_port
        )

        # Create a cursor object
        cursor = conn.cursor()

        # Check if the database exists
        cursor.execute(f"SHOW DATABASES LIKE '{rds_database}'")
        if not cursor.fetchone():
            # Create the database
            cursor.execute(f"CREATE DATABASE {rds_database}")
            conn.commit()
            logger.info(f"Database '{rds_database}' created successfully.")
        else:
            logger.info(f"Database '{rds_database}' already exists.")

        # Show all databases
        cursor.execute("SHOW DATABASES")
        databases = cursor.fetchall()

        logger.info("All databases:")
        for db in databases:
            db_name = db[0]
            logger.info(db_name)

    except mysql.connector.Error as e:
        logger.error(f"Error: {e}")
        return {
            'statusCode': 500,
            'body': f'Error connecting to or querying database: {str(e)}'
        }

    finally:
        # Close the cursor and connection
        if 'cursor' in locals():
            cursor.close()
        if 'conn' in locals():
            conn.close()

    return {
        'statusCode': 200,
        'body': 'Lambda function executed successfully.'
    }