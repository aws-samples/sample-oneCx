import boto3
import mysql.connector
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def lambda_handler(event, context):
    agent = event['agent']
    actionGroup = event['actionGroup']
    function = event['function']
    parameters = event.get('parameters', [])

    logging.info(f"Received event: {event}")

    # Get the customer mobile number and secret key from the event
    customer_mobile_number = next((param['value'] for param in event['parameters'] if param['name'] == 'customer_mobile_number'), None)
    secret_key = next((param['value'] for param in event['parameters'] if param['name'] == 'secret_key'), None)

    logging.info(f"customer_mobile_number: {customer_mobile_number}")
    logging.info(f"secret_key: {secret_key}")

    # Check if customer_mobile_number and secret_key are present and valid
    if customer_mobile_number is None or secret_key is None:
        response_body = {
            'TEXT': {
                'body': "Missing required parameters: customer_mobile_number or secret_key"
            }
        }
        status_code = 400
    else:
        try:
            customer_mobile_number = int(customer_mobile_number)
            secret_key = int(secret_key)
        except ValueError:
            response_body = {
                'TEXT': {
                    'body': "Invalid parameter values: customer_mobile_number or secret_key must be integers"
                }
            }
            status_code = 400
        else:
            # Create a DynamoDB client with the specified endpoint URL and region
            logging.info("Creating DynamoDB client...")
            ddb_client = boto3.client(
                "dynamodb",
                region_name="us-east-1",
                endpoint_url="https://vpce-0391954c85bbb2c59-6eao1lqi.dynamodb.us-east-1.vpce.amazonaws.com",
            )
            logging.info("DynamoDB client created successfully.")

            # Create a DynamoDB resource from the client
            logging.info("Creating DynamoDB resource...")
            dynamodb = boto3.resource('dynamodb', endpoint_url="https://vpce-0391954c85bbb2c59-6eao1lqi.dynamodb.us-east-1.vpce.amazonaws.com", region_name="us-east-1")
            logging.info("DynamoDB resource created successfully.")

            # Get the table
            logging.info("Getting DynamoDB table...")
            table = dynamodb.Table('customer_details')
            logging.info("DynamoDB table retrieved successfully.")

            # Get the item from the table
            logging.info("Retrieving item from DynamoDB table...")
            response = table.get_item(
                Key={
                    'customer_mobile_number': customer_mobile_number
                }
            )
            logging.info("Item retrieved from DynamoDB table successfully.")

            # Check if the item exists
            if 'Item' in response:
                item = response['Item']

                # Check if the secret key matches
                if item['customer_secret_key'] == secret_key:
                    # Connect to the RDS MySQL instance
                    rds_host = "billshock.cmk22i482qrp.us-east-1.rds.amazonaws.com"
                    rds_user = "admin"
                    rds_password = "0$aEs~??yzzpODr.W+exAlZr_({K"
                    rds_database = "billshock"

                    try:
                        logging.info("Connecting to RDS MySQL instance...")
                        conn = mysql.connector.connect(
                            host=rds_host,
                            user=rds_user,
                            password=rds_password,
                            database=rds_database
                        )
                        logging.info("Connected to RDS MySQL instance successfully.")

                        # Get a cursor
                        cursor = conn.cursor()

                        # Get the last month's bill for the customer
                        query = """
                            SELECT *
                            FROM customer_bills_overview
                            WHERE customer_mobile_number = %s
                            ORDER BY billing_month DESC
                            LIMIT 1;
                        """
                        logging.info("Executing query to get last month's bill...")
                        cursor.execute(query, (customer_mobile_number,))
                        last_month_bill = cursor.fetchone()
                        logging.info("Last month's bill retrieved successfully.")

                        if last_month_bill:
                            # Analyze why the last month's bill is higher than previous months
                            previous_month_query = """
                                SELECT *
                                FROM customer_bills_overview
                                WHERE customer_mobile_number = %s
                                ORDER BY billing_month DESC
                                LIMIT 1 OFFSET 1;
                            """
                            logging.info("Executing query to get previous month's bill...")
                            cursor.execute(previous_month_query, (customer_mobile_number,))
                            previous_month_bill = cursor.fetchone()
                            logging.info("Previous month's bill retrieved successfully.")

                            if previous_month_bill:
                                last_month_total = last_month_bill[-1]
                                previous_month_total = previous_month_bill[-1]

                                if last_month_total > previous_month_total:
                                    analysis = f"Last month's bill ({last_month_total}) is higher than the previous month ({previous_month_total}) by {last_month_total - previous_month_total}."
                                    analysis += "\nPossible reasons:\n"

                                    # Compare relevant columns from last_month_bill and previous_month_bill
                                    if last_month_bill[5] > previous_month_bill[5]:
                                        analysis += f"- Increased data usage: {last_month_bill[5]} MB (Previous month: {previous_month_bill[5]} MB), Cost: {last_month_bill[6]} (Previous month: {previous_month_bill[6]})\n"

                                    if last_month_bill[7] > previous_month_bill[7]:
                                        analysis += f"- Increased roaming data usage: {last_month_bill[7]} MB (Previous month: {previous_month_bill[7]} MB), Cost: {last_month_bill[8]} (Previous month: {previous_month_bill[8]})\n"

                                    if last_month_bill[9] > previous_month_bill[9]:
                                        analysis += f"- Increased call duration: {last_month_bill[9]} minutes (Previous month: {previous_month_bill[9]} minutes), Cost: {last_month_bill[10]} (Previous month: {previous_month_bill[10]})\n"

                                    if last_month_bill[11] > previous_month_bill[11]:
                                        analysis += f"- Increased roaming call duration: {last_month_bill[11]} minutes (Previous month: {previous_month_bill[11]} minutes), Cost: {last_month_bill[12]} (Previous month: {previous_month_bill[12]})\n"
                                else:
                                    analysis = "Last month's bill is not higher than the previous month."
                            else:
                                analysis = "No previous month's bill found for analysis."
                        else:
                            analysis = "No last month's bill found for the customer."

                        response_body = {
                            'TEXT': {
                                'body': analysis
                            }
                        }
                        status_code = 200

                    except mysql.connector.Error as e:
                        logging.error(f"Error connecting to RDS MySQL: {e}")
                        response_body = {
                            'TEXT': {
                                'body': f"Error connecting to RDS MySQL: {e}"
                            }
                        }
                        status_code = 500

                    finally:
                        # Close the cursor and connection
                        if 'cursor' in locals():
                            cursor.close()
                            logging.info("Cursor closed successfully.")
                        if 'conn' in locals():
                            conn.close()
                            logging.info("RDS MySQL connection closed successfully.")

                else:
                    response_body = {
                        'TEXT': {
                            'body': f"Secret key mismatch for mobile number: {customer_mobile_number}"
                        }
                    }
                    status_code = 400
            else:
                response_body = {
                    'TEXT': {
                        'body': f"No customer record found for mobile number: {customer_mobile_number}"
                    }
                }
                status_code = 404

    function_response = {
        'actionGroup': actionGroup,
        'function': function,
        'functionResponse': {
            'responseBody': response_body,
            'statusCode': status_code
        }
    }

    session_attributes = event['sessionAttributes']
    prompt_session_attributes = event['promptSessionAttributes']

    action_response = {
        'messageVersion': '1.0',
        'response': function_response,
        'sessionAttributes': session_attributes,
        'promptSessionAttributes': prompt_session_attributes
    }

    return action_response