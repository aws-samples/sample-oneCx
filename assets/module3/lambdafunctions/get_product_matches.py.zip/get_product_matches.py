import os
import json
import boto3
from botocore.exceptions import ClientError

def get_top_product_matches(customer_segmentation, mapped_products, num_matches=3):
    # Read the mapped_products.json file

    # Initialize the Bedrock client
    bedrock = boto3.client('bedrock-runtime')

    # Prepare the prompt for Claude 3 Sonnet
    prompt = f"""
    You are a product recommendation specialist tasked with finding the best matches for a customer based on their segmentation data. Follow these instructions carefully, executing each step in order:
    
    1. Review the customer segmentation data:
    {json.dumps(customer_segmentation, indent=2)}
    
    2. Examine the available product catalog:
    {json.dumps(mapped_products, indent=2)}
    
    3. Follow these filtering steps sequentially to narrow down the product offerings:
    
       Step 1: Mobile Phone Matching (CRITICAL)
       - IMPORTANT: Carefully check if mobile phone impressions exist in the segmentation data.
       - If mobile phone impressions are present, ONLY consider products with matching phone models.
       - If NO mobile phone impressions are present, EXCLUSIVELY filter for SIM-only plans.
       - Do NOT include any mobile phone pay monthly plans if there are no mobile phone impressions.
    
       Step 2: Spend Level Matching
       - From the results of Step 1, filter for products that match or slightly exceed the customer's current spend level.
       - Eliminate any plans with lower spend levels than the customer's current spend.
    
       Step 3: Usage Matching
       - From the results of Step 2, filter for products that best match the customer's:
         a) Data usage
         b) Voice usage
         c) Video streaming usage
         d) Text usage
    
       Step 4: Coverage Solution (if applicable)
       - If the customer has poor coverage, include one indoor coverage solution in your considerations.
    
    4. Based on the filtering process above, identify the top {num_matches} product offerings that best match the customer's profile.
    
    5. For each match, provide a brief explanation of why it was selected, starting with how it met the criteria in Step 1.
    
    6. Format your response as a JSON object with the following structure:
    {{
        "top_matches": [
            {{
                "product_name": "Name of the product",
                "price":"Price of the product"
                "reasoning": "Explanation for why this product matches, beginning with Step 1 criteria"
            }},
            ...
        ]
    }}
    
    Important:
    - Strictly adhere to the Step 1 criteria. This is crucial for correct recommendations.
    - Follow the steps in the exact order given.
    - Provide only the JSON output, with no additional text before or after.
    - Ensure your reasoning is concise but informative, always starting with how Step 1 criteria were met.
    """
    #print (prompt)
    
    # Call Claude 3 Sonnet using Amazon Bedrock
    try:
        response = bedrock.invoke_model(
            modelId='anthropic.claude-3-sonnet-20240229-v1:0',
                contentType='application/json',
                accept='application/json',
                body=json.dumps({
                    "anthropic_version": "bedrock-2023-05-31",
                    "max_tokens": 2000,
                    "messages": [
                        {
                            "role": "user",
                            "content": prompt
                        }
                    ],
                    "temperature": 1.0
                })
            )
        
        response_body = json.loads(response['body'].read())
        matches = json.loads(response_body['content'][0]['text'])
        
        return matches['top_matches']
    
    except ClientError as e:
        print(f"An error occurred: {e}")
        return []


def lambda_handler(event, context):
    print(event)
    # get the action group used during the invocation of the lambda function
    actionGroup = event.get('actionGroup', '')
    
    # name of the function that should be invoked
    function = event.get('function', '')
    
    # parameters to invoke function with
    parameters = {param['name']: param['value'] for param in event['parameters']}

    if function == 'get_product_matches':
        customer_segmentation = parameters.get('customer_segmentation')
        
        # Fetch the product segment mapping from S3
        product_segment_mapping = fetch_product_segment_mapping()
        
        if customer_segmentation and product_segment_mapping:
            try:    
                # get matching products
                product_matches = get_top_product_matches(customer_segmentation, product_segment_mapping, num_matches=3)
                print(product_matches)
                responseBody = {'TEXT': {'body': json.dumps(product_matches)}}
                print(responseBody)
            except json.JSONDecodeError:
                responseBody = {'TEXT': {'body': 'Invalid JSON format for product matches'}}
        else:
            responseBody = {'TEXT': {'body': 'Missing segmentation output or product segment mapping'}}
    else:
        responseBody = {'TEXT': {'body': 'Invalid function'}}

    action_response = {
        'actionGroup': actionGroup,
        'function': function,
        'functionResponse': {
            'responseBody': responseBody
        }
    }

    function_response = {'response': action_response, 'messageVersion': event['messageVersion']}
    print("Response: {}".format(function_response))

    return function_response

def fetch_product_segment_mapping():
    # Fetch the S3 bucket name and key from environment variables
    bucket_name = os.environ['CONFIG_BUCKET']
    key = os.environ['PRODUCT_SEGMENT_MAPPING_KEY']

    # Initialize S3 client
    s3 = boto3.client('s3')

    try:
        # Fetch the product segment mapping from S3
        response = s3.get_object(Bucket=bucket_name, Key=key)
        product_segment_mapping = json.load(response['Body'])
        return product_segment_mapping
    except ClientError as e:
        print(f"Error fetching product segment mapping from S3: {str(e)}")
        return None