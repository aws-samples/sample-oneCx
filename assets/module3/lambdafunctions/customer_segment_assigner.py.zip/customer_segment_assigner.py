import boto3
import json
import requests
from datetime import datetime
import os
from botocore.exceptions import ClientError

# Initialize Bedrock client
bedrock_runtime = boto3.client(service_name='bedrock-runtime')

# Initialize Secrets Manager client
secrets_manager = boto3.client('secretsmanager')

def get_customer_journey(customer_id):
    # Get API URL from environment variable
    url = os.environ['API_URL']
    
    # Get API key from Secrets Manager
    secret_arn = os.environ['SECRET_ARN']
    try:
        secret_response = secrets_manager.get_secret_value(SecretId=secret_arn)
        api_key = json.loads(secret_response['SecretString'])['get_customer_journey']
    except Exception as e:
        print(f"Error retrieving API key: {str(e)}")
        return None
    
    # Query parameters
    params = {
        "customer_id": customer_id
    }
    
    # Headers
    headers = {
        "x-api-key": api_key
    }
    
    try:
        # Make the GET request
        response = requests.get(url, params=params, headers=headers)
        
        # Check if the request was successful
        if response.status_code == 200:
            # Parse and return the JSON response
            return response.json()
        else:
            # Handle error cases
            print(f"Error: HTTP {response.status_code} - {response.text}")
            return None
    
    except requests.RequestException as e:
        # Handle any exceptions that occur during the request
        print(f"An error occurred: {e}")
        return None 


def analyze_customer(journey):
    model_id = 'anthropic.claude-3-sonnet-20240229-v1:0'
    
    # Retrieve S3 bucket name and key from environment variables
    s3_bucket = os.environ.get('CONFIG_BUCKET')
    s3_key = os.environ.get('SEGMENT_CONFIG_KEY')
    
    if not s3_bucket or not s3_key:
        raise ValueError("S3 bucket name or key not found in environment variables")
    
    # Initialize S3 client
    s3_client = boto3.client('s3')
    
    try:
        # Retrieve segment_config from S3
        response = s3_client.get_object(Bucket=s3_bucket, Key=s3_key)
        segment_config = json.loads(response['Body'].read().decode('utf-8'))
    except ClientError as e:
        print(f"Error retrieving segment_config from S3: {e}")
        raise
    
    system_prompt = """You are an expert in analyzing customer journeys and categorizing customers based on their behavior and usage patterns.
    You can extract relevant information from event descriptions,calculate averages accurately, and use the segment configuration to classify customers"""
    
    user_message = {
        "role": "user",
        "content": f"""Analyze the following customer journey by referring to the segment configuration:

Customer Journey:
{json.dumps(journey, indent=2)}

Segment Configuration:
{json.dumps(segment_config, indent=2)}

Do not use your own knowledge in analysis. Only use the above given customer journey and segment_configuration.

Analysis steps:

1. Calculate the average spend (bill amount) from the event descriptions and analyze based on spend thresholds in the segementation config.

2. Calculate the average usage patterns for video streaming, voice minutes, and data browsing from the event descriptions and analyze based on spend thresholds in the segementation config.

3. Identify any phone models or types of offerings the customer has shown interest in. If no phone impressions in the customer journey, leave the phone_models section empty.

4. Identify any offers that the customer has engaged with. If not offer engaged events then leave the offering_type section empty.

4. Calculate the average service outage, dropped calls, coverage issues, voice quality, and throughput issues in the customer's Quality of Experience (QoE). If you do not find issues of a particular type, then mark it as per the good experience threshold.

5. Calculate the average impressions made by the customer on mobile phone models and product offerings. Organize the data based on the segmentation config.

5. Based on the analysis and the provided segment configuration, categorize the customer into appropriate segments for each category (Spend, Usage, Impressions, Network Experience) - Use a json payload with the applicable fields found from the segmentation_config.

6. Provide a brief explanation for your categorization in each segment.

Please structure your response as follows:
1. Customer Segmentation :

2. Explanation"""
    }

    body = json.dumps({
        "anthropic_version": "bedrock-2023-05-31",
        "max_tokens": 2000,
        "temperature":1,
        "system": system_prompt,
        "messages": [user_message]
    })
    print(body)
    try:
        body_bytes = body.encode('utf-8')
        response = bedrock_runtime.invoke_model(body=body_bytes, modelId=model_id)
        response_body = json.loads(response.get('body').read())
        print(response_body)
        return response_body['content'][0]['text']
    except Exception as e:
        print(f"An error occurred while analyzing the customer journey: {str(e)}")
        return None
    

def lambda_handler(event, context):
    print(event)
    # get the action group used during the invocation of the lambda function
    actionGroup = event.get('actionGroup', '')
    
    # name of the function that should be invoked
    function = event.get('function', '')
    
    # parameters to invoke function with
    parameters = {param['name']: param['value'] for param in event['parameters']}

    if function == 'segment_customer':
        journey = parameters.get('customer_journey')
        customer_id = parameters.get('customer_id')
        offer_eligibility_reasons = parameters.get('offer_eligibility_reasons')
        if customer_id:
            try:
                #journey_data = json.loads(journey)
                #print(journey)
                
                #get customer journey events
                journey_data = get_customer_journey(customer_id)
                journey_events = journey_data['events']
                customer_segmentation = analyze_customer(journey_events)
                print(customer_segmentation)
                response = json.dumps({
                        'customer_segmentation': customer_segmentation,
                        'offer_eligibility_reasons': offer_eligibility_reasons
                    })
                
                responseBody = {'TEXT': {'body': response}}
                print(responseBody)
            except json.JSONDecodeError:
                responseBody = {'TEXT': {'body': 'Error in customer segementation calculation'}}
        else:
            responseBody = {'TEXT': {'body': 'Missing customer id parameter'}}

    else:
        responseBody = {'TEXT': {'body': 'Invalid function'}}

    action_response = {
        'actionGroup': actionGroup,
        'function': function,
        'functionResponse': {
            'responseBody': responseBody
        }
    }

    function_response = {'response': action_response, 'messageVersion': event['messageVersion']}
    print("Response: {}".format(function_response))

    return function_response