import json
import os
import boto3
import requests
from botocore.exceptions import ClientError

def get_secret():
    secret_arn = os.environ['SECRET_ARN']
    region_name = "us-west-2"

    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name
    )

    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=secret_arn
        )
    except ClientError as e:
        raise e

    secret = get_secret_value_response['SecretString']
    return json.loads(secret)['GetCustomerJourneyAPIKeyId']

def get_api_key(api_key_id):
    """
    Retrieves an API key value given its ID.
    
    Args:
        api_key_id (str): The ID of the API key to retrieve
        
    Returns:
        str: The API key value if successful
        None: If the API key cannot be retrieved
    """
    try:
        # Create an API Gateway client
        apigateway_client = boto3.client('apigateway')
        
        # Get the API key
        response = apigateway_client.get_api_key(
            apiKey=api_key_id,
            includeValue=True  # This is required to get the actual key value
        )
        
        # Return the API key value
        return response.get('value')
        
    except ClientError as e:
        print(f"Error retrieving API key: {e}")
        return None
    except Exception as e:
        print(f"Unexpected error: {e}")
        return None



def lambda_handler(event, context):
    print(event)
    # Get the API URL from environment variable
    api_url = os.environ['API_URL']
    
    # Get the customer_id from the event
    customer_id_string = event['node']['inputs'][0]['value']  # Default to '2' if not provided
    customer_id_json = json.loads(customer_id_string)
    customer_id = customer_id_json['customer_id']
    print(customer_id)
    
    # Get the API key from Secrets Manager
    api_key_id = get_secret()
    print(api_key_id)

    api_key = get_api_key(api_key_id)
    
    # Construct the full URL
    full_url = f"{api_url}?customer_id={customer_id}"
    
    # Set up the headers
    headers = {
        'x-api-key': api_key
    }
    # Construct the query parameters
    params = {
        "customer_id": customer_id
    }

    

    try:
        # Make the API request
        response = requests.get(api_url, params=params, headers=headers)
        
        # Make the API request
        #response = requests.get(full_url, headers=headers)
        
        # Raise an exception for bad status codes
        response.raise_for_status()
        
        # Return the API response
        print(response.json())
        return response.json()
        
    except requests.RequestException as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }