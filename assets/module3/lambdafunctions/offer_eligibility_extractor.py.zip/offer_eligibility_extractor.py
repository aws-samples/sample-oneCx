import json

def lambda_handler(event, context):
    print(event)
    # Extract the value string
    value_string = event['node']['inputs'][0]['value']
    print(value_string)
    # Remove the triple backticks and 'json' from the beginning and end
    json_string = value_string.strip()
    if json_string.startswith('```json'):
        json_string = json_string.removeprefix('```json').removesuffix('```').strip()
    elif json_string.startswith('```'):
        json_string = json_string.removeprefix('```').removesuffix('```').strip()
    
    print(json_string)
    
    # Parse the JSON string
    data = json.loads(json_string)
    
    # Extract only the offer eligibility and reasons
    extracted_data = {
        "customer_id": data['customer_id'],
        "offer_eligible": data["offer_eligible"],
        "reasons": [
            {
                "reason": reason["reason"],
                "priority": reason["priority"]
            }
            for reason in data["reasons"]
        ]
    }
    
    # Convert the extracted data back to a JSON string
    #result = json.dumps(extracted_data, indent=2)
    
    return extracted_data