import json
import boto3
bedrock = boto3.client('bedrock-runtime')
def analyze_offers(recommended_products, customer_profile):
    # Combine system and user messages into a single user message
    user_message = {
        "role": "user",
        "content": f"""You are an AI assistant for a telecom company. Analyze the following product offerings and customer profile to provide recommendations.

Customer Profile:
{json.dumps(customer_profile, indent=2)}

Recommended Products:
{json.dumps(recommended_products, indent=2)}

Based on the customer profile and recommended products, determine the offer negotiation band using the following rules:
1. If time remaining is less than 4 months and churn propensity is greater than 0.7, then offer discount is 10%.
2. If time remaining is less than 4 months and churn propensity is greater than 0.5 but less than 0.7, then offer discount is 5%.
3. If time remaining is greater than 3 months and churn propensity is greater than 0.7, then offer discount is 5%.
4. In all other cases the offer discount is 2%.

Please format your response as a JSON object by adding the key : "offer_negotiation_band" to the recommended products. Only respond with the json payload.
"""
    }

    # Call Claude 3 using Bedrock
    response = bedrock.invoke_model(
        modelId='anthropic.claude-3-sonnet-20240229-v1:0',
        contentType='application/json',
        accept='application/json',
        body=json.dumps({
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": 1000,
            "temperature":1,
            "messages": [user_message]
        })
    )

    # Parse the response
    result = json.loads(response['body'].read())
    analyzed_offers = json.loads(result['content'][0]['text'])

    return analyzed_offers

def lambda_handler(event, context):
    print(event)
    # get the action group used during the invocation of the lambda function
    actionGroup = event.get('actionGroup', '')
    
    # name of the function that should be invoked
    function = event.get('function', '')
    
    # parameters to invoke function with
    parameters = {param['name']: param['value'] for param in event['parameters']}

    if function == 'get_offer_negotiation_bands':
        recommended_products = parameters.get('recommended_products')
        #customer_profile = parameters.get('customer_profile')
        customer_profile =  json.dumps({
    "customer_id": 1,
    "address": "796 Main St, City, State, ZIP",
    "contact_number": "+1 550-673-4649",
    "email": "customer2@example.com",
    "persona": "risk taking",
    "current_plan": "Ultimate",
    "monthly_bill": "120.00",
    "churn_propensity": "0.8017",
    "contract_period": 24,
    "ltv": 571.18,
    "tenure": 7,
    "time_remaining": 2,
    "regional_competitor_pricing": {"Competitor A":118.19,"Competitor B":129.03,"Competitor C":123.67}
})
        if recommended_products:
            try:
                analyzed_offers = analyze_offers(recommended_products, customer_profile)
                responseBody = {'TEXT': {'body': json.dumps(analyzed_offers)}}
                print(responseBody)
            except json.JSONDecodeError:
                responseBody = {'TEXT': {'body': 'Invalid JSON format for journey parameter'}}
        else:
            responseBody = {'TEXT': {'body': 'Missing journey parameter'}}

    else:
        responseBody = {'TEXT': {'body': 'Invalid function'}}

    action_response = {
        'actionGroup': actionGroup,
        'function': function,
        'functionResponse': {
            'responseBody': responseBody
        }
    }

    function_response = {'response': action_response, 'messageVersion': event['messageVersion']}
    print("Response: {}".format(function_response))

    return function_response
