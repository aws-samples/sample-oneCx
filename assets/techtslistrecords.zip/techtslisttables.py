import pymysql
import logging
import boto3
import json

# Set up logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def format_table(headers, rows):
    # Ensure headers and rows are lists of lists
    headers = list(headers)
    rows = [list(row) for row in rows]
    
    # Calculate column widths
    widths = [max(len(str(cell)) for cell in [headers[i]] + [row[i] for row in rows]) for i in range(len(headers))]
    
    # Format the header
    header = " | ".join(f"{str(h):<{w}}" for h, w in zip(headers, widths))
    separator = "-+-".join("-" * w for w in widths)
    
    # Format the rows
    formatted_rows = [
        " | ".join(f"{str(val):<{w}}" for val, w in zip(row, widths))
        for row in rows
    ]
    
    # Combine all parts
    return "\n".join([header, separator] + formatted_rows)

def lambda_handler(event, context):
    try:
        # Get RDS host from Parameter Store
        ssm_client = boto3.client('ssm')
        rds_host = ssm_client.get_parameter(Name='/ccj/RDS/TechsupportDBEndpoint')['Parameter']['Value']

        # Get RDS password from Secrets Manager
        secrets_client = boto3.client('secretsmanager')
        secret_response = secrets_client.get_secret_value(SecretId='ccj-techsupport-db-secret')
        secret = json.loads(secret_response['SecretString'])
        rds_password = secret['password']

        rds_user = 'admin'
        rds_database = 'techsupport'

        # Connect to the RDS instance
        logger.info("Connecting to RDS instance...")
        conn = pymysql.connect(
            host=rds_host,
            user=rds_user,
            password=rds_password,
            connect_timeout=5
        )

        with conn.cursor() as cur:
            # Create the database if it doesn't exist
            cur.execute(f"CREATE DATABASE IF NOT EXISTS {rds_database}")
            conn.commit()
            logger.info(f"Database '{rds_database}' created or already exists.")

            # Switch to the techsupport database
            cur.execute(f"USE {rds_database}")
            conn.commit()

            tables = [
                ('customerauth', """
                    SELECT customer_id, secret_key
                    FROM customerauth;
                """),
                ('customerbillingdetails', """
                    SELECT customer_id, secret_key, DATE_FORMAT(bill_month, '%Y-%m-%d') AS bill_month, service_plan,
                           monthly_charge, data_usage, overage_charges, taxes, total_amount,
                           monthly_data_allowed_download, monthly_data_allowed_upload,
                           allowed_upload_speed, allowed_download_speed, bill_paid
                    FROM customerbillingdetails;
                """),
                ('customercurrentmonth', """
                    SELECT customer_id, secret_key, DATE_FORMAT(current_month, '%Y-%m-%d') AS current_month,
                           current_total_download, current_total_upload,
                           monthly_data_allowed_download, monthly_data_allowed_upload,
                           allowed_upload_speed, allowed_download_speed,
                           COALESCE(new_upload_speed, 0) AS new_upload_speed,
                           COALESCE(new_download_speed, 0) AS new_download_speed
                    FROM customercurrentmonth;
                """),
                ('customermodemdetails', """
                    SELECT customer_id, node_id, modem_serial_number, modem_model, modem_manufacturer,
                           modem_ip, modem_firmware_version, DATE_FORMAT(modem_activation_date, '%Y-%m-%d') AS modem_activation_date,
                           modem_status, COALESCE(modem_notes, '') AS modem_notes
                    FROM customermodemdetails;
                """),
                ('nodedetails', """
                    SELECT node_id, node_name, node_location_city, node_location_state, node_location_zipcode,
                           node_status, COALESCE(DATE_FORMAT(node_next_maintenance_date, '%Y-%m-%d'), '') AS node_next_maintenance_date
                    FROM nodedetails;
                """)
            ]

            for table_name, select_query in tables:
                logger.info(f"\nTable: {table_name}")
                cur.execute(select_query)
                rows = cur.fetchall()
                if rows:
                    headers = [i[0] for i in cur.description]
                    formatted_table = format_table(headers, rows)
                    logger.info(f"\n{formatted_table}")
                else:
                    logger.info("No data found in the table.")

        conn.close()

        return {
            'statusCode': 200,
            'body': 'Table contents listed successfully'
        }

    except Exception as e:
        logger.error(f"Error: {e}")
        return {
            'statusCode': 500,
            'body': 'Error occurred while listing table contents'
        }