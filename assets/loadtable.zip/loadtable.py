import boto3
import mysql.connector
from datetime import date
import random
import logging
import json

# Set up logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# SSM client
ssm_client = boto3.client('ssm')

# Secrets Manager client
secrets_client = boto3.client('secretsmanager')

def lambda_handler(event, context):
    # Retrieve RDS host from Parameter Store
    try:
        rds_host = ssm_client.get_parameter(Name='/ccj/RDS/BillshockDBEndpoint')['Parameter']['Value']
    except Exception as e:
        logger.error(f"Error retrieving RDS host from Parameter Store: {e}")
        return {
            'statusCode': 500,
            'body': 'Error retrieving RDS host'
        }

    # Retrieve RDS password from Secrets Manager
    try:
        secret_response = secrets_client.get_secret_value(SecretId='ccj-billshock-db-secret')
        secret = json.loads(secret_response['SecretString'])
        rds_password = secret['password']
    except Exception as e:
        logger.error(f"Error retrieving RDS password from Secrets Manager: {e}")
        return {
            'statusCode': 500,
            'body': 'Error retrieving RDS password'
        }

    # Retrieve DynamoDB endpoint from Parameter Store
    try:
        dynamodb_endpoint = ssm_client.get_parameter(Name='/network/DynamoDBEndpointDNSEntry')['Parameter']['Value']
    except Exception as e:
        logger.error(f"Error retrieving DynamoDB endpoint from Parameter Store: {e}")
        return {
            'statusCode': 500,
            'body': 'Error retrieving DynamoDB endpoint'
        }

    # Retrieve DynamoDB table name from Parameter Store
    try:
        dynamodb_table_name = ssm_client.get_parameter(Name='/DynamoDB/ccj/TableName')['Parameter']['Value']
    except Exception as e:
        logger.error(f"Error retrieving DynamoDB table name from Parameter Store: {e}")
        return {
            'statusCode': 500,
            'body': 'Error retrieving DynamoDB table name'
        }

    # Get the current region
    region = boto3.session.Session().region_name

    # Create a DynamoDB client with the specified endpoint URL and region
    logger.info("Creating DynamoDB client...")
    ddb_client = boto3.client(
        "dynamodb",
        region_name=region,
        endpoint_url=dynamodb_endpoint,
    )
    logger.info("DynamoDB client created successfully.")

    # Create a DynamoDB resource from the client
    logger.info("Creating DynamoDB resource...")
    dynamodb = boto3.resource('dynamodb', endpoint_url=dynamodb_endpoint, region_name=region)
    logger.info("DynamoDB resource created successfully.")

    # Get the table
    logger.info(f"Getting DynamoDB table: {dynamodb_table_name}")
    table = dynamodb.Table(dynamodb_table_name)
    logger.info("DynamoDB table retrieved successfully.")

    # Check if there are any items in the table
    response = table.scan(Select='COUNT')
    item_count = response['Count']

    if item_count > 0:
        logger.info(f"Found {item_count} items in the table. Deleting all items...")
        
        # Scan the table and delete all items
        scan = table.scan()
        with table.batch_writer() as batch:
            for each in scan['Items']:
                batch.delete_item(
                    Key={
                        'customer_mobile_number': each['customer_mobile_number']
                    }
                )
        
        logger.info("All items deleted from the table.")
    else:
        logger.info("No items found in the table. Proceeding with insertion.")

    # AWS RDS connection details
    rds_user = "admin"
    rds_database = "billshock"

    try:
        logger.info("Connecting to RDS instance...")
        # Connect to the RDS MySQL instance
        conn = mysql.connector.connect(
            host=rds_host,
            user=rds_user,
            password=rds_password,
            database=rds_database
        )

        logger.info("Connected to RDS instance.")

        # Get a cursor
        cursor = conn.cursor()

        logger.info("Starting record insertion...")

        # Insert records
        insert_query = """
        INSERT INTO customer_bills_overview
        (customer_mobile_number, customer_email, customer_secret_key, customer_dob, billing_month,
        data_usage_mb, data_cost, roaming_data_usage_mb, roaming_data_cost,
        call_duration, call_cost, roaming_call_duration, roaming_call_cost, total_amount)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """

        num_customers = 10
        customer_data = {}

        for customer in range(num_customers):
            customer_mobile_number = 9000000001 + customer
            customer_email = f"user{customer+1}@example.com"
            customer_secret_key = 435601 + customer
            customer_dob = date(random.randint(1950, 2000), random.randint(1, 12), random.randint(1, 28))

            customer_data[customer_mobile_number] = customer_secret_key

            months = [date(2024, 7, 1), date(2024, 8, 1), date(2024, 9, 1)]  # Updated months for all customers

            for i, billing_month in enumerate(months):
                data_usage = random.randint(100, 900)
                data_cost = round(data_usage * 0.01, 2)
                
                if i == 2:  # September
                    roaming_data_usage_mb = 20 * 70  # 50 times of last 2 months
                    roaming_call_duration = 5 * 4  # 4 times of last 2 months
                else:
                    roaming_data_usage_mb = 20  # Fixed 20 MB for July and August
                    roaming_call_duration = 5  # Fixed 5 minutes for July and August

                roaming_data_cost = round(roaming_data_usage_mb * 0.05, 2)  # Data roaming rate is .05 per mb
                call_duration = 50  # Set call duration to 50 for all customers and months
                call_cost = round(call_duration * 0.1, 2)
                roaming_call_cost = round(roaming_call_duration * 0.5, 2)  # Roaming call cost is .5 per minute
                total_amount = round(data_cost + roaming_data_cost + call_cost + roaming_call_cost, 2)

                record_data = (customer_mobile_number, customer_email, customer_secret_key, customer_dob, billing_month,
                               data_usage, data_cost, roaming_data_usage_mb, roaming_data_cost,
                               call_duration, call_cost, roaming_call_duration, roaming_call_cost, total_amount)

                logger.info(f"Inserting record: {record_data}")
                cursor.execute(insert_query, record_data)

        conn.commit()
        logger.info(f"{num_customers * 3} records inserted successfully.")

        # Insert unique customer data into DynamoDB using put_item
        for mobile_number, secret_key in customer_data.items():
            try:
                table.put_item(
                    Item={
                        'customer_mobile_number': mobile_number,
                        'customer_secret_key': secret_key
                    }
                )
                logger.info(f"Inserted item for mobile number: {mobile_number}")
            except Exception as e:
                logger.error(f"Error inserting item for mobile number {mobile_number}: {e}")

        logger.info(f"{len(customer_data)} unique customer records inserted into DynamoDB.")

        logger.info("Fetching and displaying all records from RDS...")

        # Fetch and display all records from RDS
        select_query = "SELECT * FROM customer_bills_overview"
        cursor.execute(select_query)
        records = cursor.fetchall()

        # Get column names
        column_names = [desc[0] for desc in cursor.description]

        # Print records in a tabular format
        logger.info("\nAll records in customer_bills_overview:")
        logger.info("| " + " | ".join(column_names) + " |")
        logger.info("-" * (len(column_names) * 20 + len(column_names) * 2 + 1))
        for record in records:
            logger.info("| " + " | ".join(str(value) for value in record) + " |")

    except (mysql.connector.Error, boto3.exceptions.Boto3Error) as e:
        logger.error(f"Error: {e}")
        return {
            'statusCode': 500,
            'body': f'Error connecting to or querying database: {str(e)}'
        }

    finally:
        logger.info("Closing cursor and connection...")
        # Close the cursor and connection
        if 'cursor' in locals():
            cursor.close()
        if 'conn' in locals():
            conn.close()
        logger.info("Cursor and connection closed.")

    return {
        'statusCode': 200,
        'body': 'Lambda function executed successfully.'
    }