import json
import urllib3
import os
import random
import boto3
from botocore.exceptions import ClientError
def get_secret():
    secret_arn = os.environ['SECRET_ARN']
    region_name = "us-west-2"
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name
    )
    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=secret_arn
        )
    except ClientError as e:
        raise e
    secret = get_secret_value_response['SecretString']
    return json.loads(secret)['PutCustomerJourneyAPIKeyId']
def get_api_key(api_key_id):
    try:
        apigateway_client = boto3.client('apigateway')
        response = apigateway_client.get_api_key(
            apiKey=api_key_id,
            includeValue=True
        )
        return response.get('value')
    except ClientError as e:
        print(f"Error retrieving API key: {e}")
        return None
    except Exception as e:
        print(f"Unexpected error: {e}")
        return None
def lambda_handler(event, context):
    print(event)
    print("Lambda function started")
    print(f"Received event: {json.dumps(event, indent=2)}")
    try:
        # Extract the relevant information from the input
        input_data = json.loads(event['node']['inputs'][0]['value'])
        transcript_analysis = input_data['transcript_analysis']
        # Generate a random positive integer for event_id
        event_id = random.randint(1, 1000000)
        # Create the JSON object expected by the API
        api_payload = {
            "event_type_id": "1",
            "customer_id": transcript_analysis['customer_id'],
            "event_id": str(event_id),
            "event_description": transcript_analysis['summary'],
            "timestamp": transcript_analysis['date'],
            "additional_attributes": {
                "duration": transcript_analysis['duration'],
                "agent_id": transcript_analysis['agent_id'],
                "issues": transcript_analysis['issues'],
                "actions": transcript_analysis['actions'],
                "outcomes": transcript_analysis['outcomes']
            }
        }
        print(f"Prepared API payload: {json.dumps(api_payload, indent=2)}")
        # API endpoint
        api_endpoint = os.environ['API_ENDPOINT']
        # Get the API key
        api_key_id = get_secret()
        api_key = get_api_key(api_key_id)
        print(api_key)
        if not api_key:
            raise Exception("Failed to retrieve API key")
        # Set up the headers
        headers = {
            'Content-Type': 'application/json',
            'x-api-key': api_key
        }
        # Set up http client
        http = urllib3.PoolManager()
        print("Sending request to API...")
        max_retries = 2
        retry_count = 0
        while retry_count <= max_retries:
            try:
                # Send the JSON object to the API
                response = http.request('POST',
                                        api_endpoint,
                                        body=json.dumps(api_payload).encode('utf-8'),
                                        headers=headers)
                print(f"API Response Status: {response.status}")
                print(f"API Response Headers: {response.headers}")
                print(f"API Response Body: {response.data.decode('utf-8')}")
                # Check if the request was successful
                if response.status == 200:
                    print("Request successful")
                    return {
                        'statusCode': 200,
                        'body': json.dumps('Successfully sent JSON to API')
                    }
                elif response.status == 502 and retry_count < max_retries:
                    print(f"Received 502 error. Retrying... (Attempt {retry_count + 1})")
                    retry_count += 1
                else:
                    error_detail = response.data.decode('utf-8')
                    print(f"API Error: Status {response.status}, Body: {error_detail}")
                    return {
                        'statusCode': response.status,
                        'body': json.dumps(f'Failed to send JSON to API. Status: {response.status}, Error: {error_detail}')
                    }
            except Exception as e:
                print(f"Error sending request: {str(e)}")
                if retry_count < max_retries:
                    print(f"Retrying... (Attempt {retry_count + 1})")
                    retry_count += 1
                else:
                    return {
                        'statusCode': 500,
                        'body': json.dumps(f'Failed to send request after {max_retries} attempts: {str(e)}')
                    }
    except KeyError as e:
        print(f"KeyError: Missing expected field in input data: {str(e)}")
        return {
            'statusCode': 400,
            'body': json.dumps(f'Invalid input data: Missing field {str(e)}')
        }
    except json.JSONDecodeError as e:
        print(f"JSON Decode Error: {str(e)}")
        return {
            'statusCode': 400,
            'body': json.dumps(f'Invalid JSON string: {str(e)}')
        }
    except Exception as e:
        print(f"Unexpected Error: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps(f'An unexpected error occurred: {str(e)}')
        }
    finally:
        print("Lambda function ended")