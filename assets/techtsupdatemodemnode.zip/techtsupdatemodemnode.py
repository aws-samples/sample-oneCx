import pymysql
import logging
import boto3
import json

# Set up logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def format_table(headers, rows):
    # Calculate column widths
    widths = [max(len(str(cell)) for cell in [header] + [row[i] for row in rows]) for i, header in enumerate(headers)]
    
    # Format the header
    header = " | ".join(f"{h:<{w}}" for h, w in zip(headers, widths))
    separator = "-+-".join("-" * w for w in widths)
    
    # Format the rows
    formatted_rows = [
        " | ".join(f"{str(val):<{w}}" for val, w in zip(row, widths))
        for row in rows
    ]
    
    # Combine all parts
    return "\n".join([header, separator] + formatted_rows)

def lambda_handler(event, context):
    try:
        # Get RDS host from Parameter Store
        ssm_client = boto3.client('ssm')
        rds_host = ssm_client.get_parameter(Name='/ccj/RDS/TechsupportDBEndpoint')['Parameter']['Value']

        # Get RDS password from Secrets Manager
        secrets_client = boto3.client('secretsmanager')
        secret_response = secrets_client.get_secret_value(SecretId='ccj-techsupport-db-secret')
        secret = json.loads(secret_response['SecretString'])
        rds_password = secret['password']

        rds_user = 'admin'
        rds_database = 'techsupport'

        # Connect to the RDS instance
        logger.info("Connecting to RDS instance...")
        conn = pymysql.connect(
            host=rds_host,
            user=rds_user,
            password=rds_password,
            database=rds_database,
            connect_timeout=5
        )

        with conn.cursor() as cur:
            # List of customer_id values to update modem_status
            customer_ids = [2000000009, 2000000008]

            # Update the modem_status to False for the specified customer_ids
            update_modem_query = """
                UPDATE customermodemdetails
                SET modem_status = False
                WHERE customer_id = %s;
            """

            for customer_id in customer_ids:
                logger.info(f"Updating modem_status for customer_id: {customer_id}")
                cur.execute(update_modem_query, (customer_id,))
                if cur.rowcount > 0:
                    logger.info(f"Modem status updated successfully for customer_id: {customer_id}")
                else:
                    logger.warning(f"No modem found for customer_id: {customer_id}")

            conn.commit()
            logger.info("Modem status updates completed.")

            # Find the node_id for customer_id=2000000002
            find_node_query = """
                SELECT node_id
                FROM customermodemdetails
                WHERE customer_id = 2000000002;
            """
            cur.execute(find_node_query)
            result = cur.fetchone()

            if result:
                node_id = result[0]
                logger.info(f"Found node_id {node_id} for customer_id 2000000002")

                # Update the node_status to False (down) in nodedetails table
                update_node_query = """
                    UPDATE nodedetails
                    SET node_status = False
                    WHERE node_id = %s;
                """
                cur.execute(update_node_query, (node_id,))
                conn.commit()

                if cur.rowcount > 0:
                    logger.info(f"Node status updated successfully for node_id: {node_id}")
                else:
                    logger.warning(f"No node found with node_id: {node_id}")
            else:
                logger.warning("No node_id found for customer_id 2000000002")

            # List contents of all tables
            tables = ['customerauth', 'customerbillingdetails', 'customercurrentmonth', 'customermodemdetails', 'nodedetails']

            for table_name in tables:
                logger.info(f"\nTable: {table_name}")
                cur.execute(f"SELECT * FROM {table_name}")
                rows = cur.fetchall()
                if rows:
                    headers = [i[0] for i in cur.description]
                    formatted_table = format_table(headers, rows)
                    logger.info(f"\n{formatted_table}")
                else:
                    logger.info("No data found in the table.")

        conn.close()

        return {
            'statusCode': 200,
            'body': 'Modem and node status update operations completed, and table contents listed'
        }

    except Exception as e:
        logger.error(f"Error: {e}")
        return {
            'statusCode': 500,
            'body': 'Error occurred during operations'
        }