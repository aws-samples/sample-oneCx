import pymysql
import logging
import boto3
import json

# Set up logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    try:
        # Get RDS host from Parameter Store
        ssm_client = boto3.client('ssm')
        rds_host = ssm_client.get_parameter(Name='/ccj/RDS/TechsupportDBEndpoint')['Parameter']['Value']

        # Get RDS password from Secrets Manager
        secrets_client = boto3.client('secretsmanager')
        secret_response = secrets_client.get_secret_value(SecretId='ccj-techsupport-db-secret')
        secret = json.loads(secret_response['SecretString'])
        rds_password = secret['password']

        rds_user = 'admin'
        rds_database = 'techsupport'

        # Parse customer_id from the event
        customer_id = None
        for param in event.get('parameters', []):
            if param['name'] == 'customer_id':
                customer_id = param['value']

        if not customer_id:
            return build_response(event, "Missing customer_id in the event payload", "REPROMPT")

        # Connect to the RDS instance
        logger.info("Connecting to RDS instance...")
        conn = pymysql.connect(
            host=rds_host,
            user=rds_user,
            password=rds_password,
            connect_timeout=5
        )

        with conn.cursor() as cur:
            # Switch to the techsupport database
            cur.execute(f"USE {rds_database}")
            logger.info(f"Switched to database '{rds_database}'")

            # Find the modem_status for the customer_id
            find_modem_status_query = """
                SELECT modem_status
                FROM customermodemdetails
                WHERE customer_id = %s;
            """
            logger.info(f"Executing find_modem_status_query with customer_id: {customer_id}")
            cur.execute(find_modem_status_query, (customer_id,))
            result = cur.fetchone()

            if result:
                modem_status = result[0]
                response_body = f"The modem status for customer with ID {customer_id} is {'UP' if modem_status else 'DOWN'}."
                return build_response(event, response_body, "REPROMPT")
            else:
                return build_response(event, "No customer modem details found for the given customer_id", "REPROMPT")

        conn.close()

    except Exception as e:
        logger.error(f"Error: {e}")
        return build_response(event, "Error occurred while processing the request", "REPROMPT")

def build_response(event, response_body, response_state):
    agent = event['agent']
    actionGroup = event['actionGroup']
    function = event['function']
    parameters = event.get('parameters', [])

    response_body = {
        'TEXT': {
            'body': response_body
        }
    }

    function_response = {
        'actionGroup': actionGroup,
        'function': function,
        'functionResponse': {
            'responseState': response_state,
            'responseBody': response_body
        }
    }

    session_attributes = event.get('sessionAttributes', {})
    prompt_session_attributes = event.get('promptSessionAttributes', {})

    action_response = {
        'messageVersion': '1.0',
        'response': function_response,
        'sessionAttributes': session_attributes,
        'promptSessionAttributes': prompt_session_attributes
    }

    return action_response