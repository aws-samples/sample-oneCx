import mysql.connector
import logging
from datetime import date, datetime, timedelta
import boto3
import json

# Set up logging to CloudWatch
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    print(event)
    try:
        # Get RDS host from Parameter Store
        ssm_client = boto3.client('ssm')
        RDS_INSTANCE_ENDPOINT = ssm_client.get_parameter(Name='/ccj/RDS/TechsupportDBEndpoint')['Parameter']['Value']

        # Get RDS password from Secrets Manager
        secrets_client = boto3.client('secretsmanager')
        secret_response = secrets_client.get_secret_value(SecretId='ccj-techsupport-db-secret')
        secret = json.loads(secret_response['SecretString'])
        DATABASE_PASSWORD = secret['password']

        rds_user = 'admin'
        rds_database = 'techsupport'

        # Parse customer_id and secret_key from the event payload
        customer_id = None
        secret_key = None
        for param in event.get('parameters', []):
            if param['name'] == 'customer_id':
                customer_id = param['value']
            elif param['name'] == 'secret_key':
                secret_key = param['value']

        if not customer_id or not secret_key:
            logger.error("Missing customer_id or secret_key in the event payload")
            return send_failure_response(event, "Missing customer_id or secret_key in the event payload")

        # Set the current date to September 17, 2024
        current_date = date(2024, 9, 17)

        # Connect to the RDS instance
        logger.info("Connecting to RDS instance...")
        conn = mysql.connector.connect(
            host=RDS_INSTANCE_ENDPOINT,
            user=rds_user,
            password=DATABASE_PASSWORD,
            database=rds_database
        )

        with conn.cursor() as cur:
            # Verify customer_id and secret_key
            verify_query = """
                SELECT COUNT(*) AS count
                FROM customerbillingdetails
                WHERE customer_id = %s AND secret_key = %s;
            """
            logger.info("Executing verify_query with customer_id: %s, secret_key: %s", customer_id, secret_key)
            cur.execute(verify_query, (customer_id, secret_key))
            result = cur.fetchone()

            if result is None or result[0] == 0:
                logger.error("Invalid customer_id or secret_key")
                return send_failure_response(event, "Invalid customer_id or secret_key")

            # Find the current month based on the current date
            current_month = date(current_date.year, current_date.month, 1)

            # Check if the customer has paid the last month's bill
            last_month = current_month - timedelta(days=1)
            last_month_start = last_month.replace(day=1)

            check_query = """
                SELECT bill_paid
                FROM customerbillingdetails
                WHERE customer_id = %s AND bill_month = %s;
            """
            logger.info("Executing check_query with customer_id: %s, bill_month: %s", customer_id, last_month_start)
            cur.execute(check_query, (customer_id, last_month_start))
            result = cur.fetchone()

            if result:
                bill_paid = result[0]
                return send_reprompt_response(event, f"Customer with ID {customer_id} has {'paid' if bill_paid else 'not paid'} the bill for the month of {last_month_start}")
            else:
                logger.error("No data found for the given customer_id and month")
                return send_failure_response(event, "No data found for the given customer_id and month")

        conn.close()

    except Exception as e:
        logger.error(f"Error: {e}")
        return send_failure_response(event, "Error occurred while processing the request")

def send_failure_response(event, message):
    agent = event['agent']
    actionGroup = event['actionGroup']
    function = event['function']
    parameters = event.get('parameters', [])
    response_body = {
        'TEXT': {
            'body': message
        }
    }
    function_response = {
        'actionGroup': actionGroup,
        'function': function,
        'functionResponse': {
            'responseState': "FAILURE",
            'responseBody': response_body
        }
    }
    session_attributes = event.get('sessionAttributes', {})
    prompt_session_attributes = event.get('promptSessionAttributes', {})
    action_response = {
        'messageVersion': '1.0',
        'response': function_response,
        'sessionAttributes': session_attributes,
        'promptSessionAttributes': prompt_session_attributes
    }
    return action_response

def send_reprompt_response(event, message):
    agent = event['agent']
    actionGroup = event['actionGroup']
    function = event['function']
    parameters = event.get('parameters', [])
    response_body = {
        'TEXT': {
            'body': message
        }
    }
    function_response = {
        'actionGroup': actionGroup,
        'function': function,
        'functionResponse': {
            'responseState': "REPROMPT",
            'responseBody': response_body
        }
    }
    session_attributes = event.get('sessionAttributes', {})
    prompt_session_attributes = event.get('promptSessionAttributes', {})
    action_response = {
        'messageVersion': '1.0',
        'response': function_response,
        'sessionAttributes': session_attributes,
        'promptSessionAttributes': prompt_session_attributes
    }
    return action_response