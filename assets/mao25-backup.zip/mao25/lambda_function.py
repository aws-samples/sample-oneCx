import json
import asyncio
from typing import Dict, Any
from multi_agent_orchestrator.orchestrator import MultiAgentOrchestrator, OrchestratorConfig
from multi_agent_orchestrator.agents import BedrockLLMAgent, BedrockLLMAgentOptions, AgentResponse, AmazonBedrockAgent, AmazonBedrockAgentOptions
from multi_agent_orchestrator.classifiers import BedrockClassifier, BedrockClassifierOptions 
from multi_agent_orchestrator.utils import Logger
import boto3
import os

# classifier
classifier = BedrockClassifier(BedrockClassifierOptions(
    model_id='anthropic.claude-3-sonnet-20240229-v1:0',
))
# Initialize orchestrator
orchestrator = MultiAgentOrchestrator(OrchestratorConfig(
  LOG_AGENT_CHAT=True,
  LOG_CLASSIFIER_CHAT=True,
  LOG_CLASSIFIER_RAW_OUTPUT=True,
  LOG_CLASSIFIER_OUTPUT=True,
  LOG_EXECUTION_TIMES=True,
  MAX_RETRIES=3,
  USE_DEFAULT_AGENT_IF_NONE_IDENTIFIED=True,
  MAX_MESSAGE_PAIRS_PER_AGENT=10
    ),
 classifier=classifier
)

ssm = boto3.client('ssm')

def get_parameter(name: str) -> str:
    response = ssm.get_parameter(Name=name, WithDecryption=True)
    return response['Parameter']['Value']

# Add agents
tech_agent = AmazonBedrockAgent(AmazonBedrockAgentOptions(
    name='network_fault_troubleshooting_agent',
    description='Your are home broadband network troubleshooting agent.   ',
    agent_id=get_parameter(os.environ['TECHSUPPORT_AGENT_ID_PARAM']),
    agent_alias_id=get_parameter(os.environ['TECHSUPPORT_AGENT_ALIAS_ID_PARAM'])
))
tech_agent1 = AmazonBedrockAgent(AmazonBedrockAgentOptions(
    name='bill_shock',
    description='You are a bill analysis agent who analyses customers bill and explain #why the bill is high compared to other months   ',
    agent_id=get_parameter(os.environ['BILLSHOCK_AGENT_ID_PARAM']),
    agent_alias_id=get_parameter(os.environ['BILLSHOCK_AGENT_ALIAS_ID_PARAM'])
))

orchestrator.add_agent(tech_agent)
orchestrator.add_agent(tech_agent1)

def serialize_agent_response(response: AgentResponse) -> Dict[str, Any]:
    """Convert AgentResponse into a JSON-serializable dictionary."""
    return {
        "metadata": {
            "agent_id": response.metadata.agent_id,
            "agent_name": response.metadata.agent_name,
            "user_input": response.metadata.user_input,
            "session_id": response.metadata.session_id,
        },
        "output": response.output.content[0]['text'],
        "streaming": response.streaming,
    }
async def handle_request(
    _orchestrator: MultiAgentOrchestrator,
    _user_input: str,
    _user_id: str,
    _session_id: str,
):
    response: AgentResponse = await _orchestrator.route_request(
        _user_input, _user_id, _session_id
    )
    print(response)
    return response

def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    try:
        print(f'event: {event}')

        body = json.loads(event['body'])
        print(f'body: {body}')

        user_input = body.get('query')
        user_id = body.get('userId')
        session_id = body.get('sessionId')
        print(f'user_input: {user_input}')
        print(f'user_id: {user_id}')
        print(f'session_id: {session_id}')

        response = asyncio.run(
            handle_request(orchestrator, user_input, user_id, session_id))
        print(f'response: {response}')
        # Serialize the AgentResponse to a JSON-compatible format
        serialized_response = serialize_agent_response(response)

        return {
            "statusCode": 200,
            "body": json.dumps(serialized_response),
            # 'headers': {
            #     'Access-Control-Allow-Origin': '*',
            #     'Access-Control-Allow-Headers': 'Content-Type',
            #     'Access-Control-Allow-Methods': 'OPTIONS,POST,GET'
            # },
        }

    except Exception as e:
        print(f"Error: {str(e)}")
        return {
            "statusCode": 500,
            "body": json.dumps({"error": "Internal Server Error"})
        }