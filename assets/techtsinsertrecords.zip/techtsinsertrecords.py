import pymysql
import logging
import random
from datetime import date
import boto3
import json

# Set up logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def generate_random_number(start, end, length):
    range_start = 10 ** (length - 1)
    range_end = (10 ** length) - 1
    return random.randint(range_start + start, range_end)

def generate_ip_address():
    ip_parts = [str(random.randint(1, 254)) for _ in range(4)]
    return '.'.join(ip_parts)

def lambda_handler(event, context):
    try:
        # Get RDS host from Parameter Store
        ssm_client = boto3.client('ssm')
        rds_host = ssm_client.get_parameter(Name='/ccj/RDS/TechsupportDBEndpoint')['Parameter']['Value']

        # Get RDS password from Secrets Manager
        secrets_client = boto3.client('secretsmanager')
        secret_response = secrets_client.get_secret_value(SecretId='ccj-techsupport-db-secret')
        secret = json.loads(secret_response['SecretString'])
        rds_password = secret['password']

        rds_user = 'admin'
        rds_database = 'techsupport'

        # Connect to the RDS instance
        logger.info("Connecting to RDS instance...")
        conn = pymysql.connect(
            host=rds_host,
            user=rds_user,
            password=rds_password,
            database=rds_database,
            connect_timeout=5
        )

        with conn.cursor() as cur:
            # Switch to the techsupport database (for extra certainty)
            cur.execute(f"USE {rds_database}")
            conn.commit()
            logger.info(f"Switched to database '{rds_database}'")

            # Generate customer data
            customer_data = []
            for i, customer_id in enumerate(range(2000000000, 2000000010)):
                secret_key = 357891 + i  # This ensures secret_key values from 357891 to 357900
                node_id = generate_random_number(4000000000, 4000000009, 10)
                modem_serial_number = generate_random_number(5000000000, 5000000009, 10)
                modem_ip = generate_ip_address()
                customer_data.append({
                    'customer_id': customer_id,
                    'secret_key': secret_key,
                    'node_id': node_id,
                    'modem_serial_number': modem_serial_number,
                    'modem_ip': modem_ip
                })

            # Insert data into 'customerauth' table
            for customer in customer_data:
                customer_id = customer['customer_id']
                secret_key = customer['secret_key']

                insert_query = """
                    INSERT INTO customerauth (customer_id, secret_key)
                    VALUES (%s, %s)
                """
                logger.info(f"Inserting data into 'customerauth' table for customer_id: {customer_id}, secret_key: {secret_key}")
                try:
                    cur.execute(insert_query, (customer_id, secret_key))
                except Exception as e:
                    logger.error(f"Error inserting data into 'customerauth' table for customer_id: {customer_id}, error: {e}")
            conn.commit()
            logger.info("Data inserted into 'customerauth' table successfully.")

            # Insert data into 'customerbillingdetails' table
            for customer in customer_data:
                customer_id = customer['customer_id']
                secret_key = customer['secret_key']
                bill_month_1 = date(2024, 7, 1)
                bill_month_2 = date(2024, 8, 1)
                service_plan = 'Premium'
                monthly_charge = 99.99
                data_usage = 1000  # 1TB
                overage_charges = 0.0
                taxes = 8.99
                total_amount = monthly_charge + overage_charges + taxes
                monthly_data_allowed_download = 1000  # 1TB
                monthly_data_allowed_upload = 100  # 100GB
                allowed_upload_speed = 50
                allowed_download_speed = 500
                bill_paid_1 = True if customer_id < 2000000005 else False
                bill_paid_2 = True if customer_id < 2000000005 else False

                insert_query = """
                    INSERT INTO customerbillingdetails (customer_id, secret_key, bill_month, service_plan, monthly_charge,
                                                        data_usage, overage_charges, taxes, total_amount,
                                                        monthly_data_allowed_download, monthly_data_allowed_upload,
                                                        allowed_upload_speed, allowed_download_speed, bill_paid)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                """
                logger.info(f"Inserting data into 'customerbillingdetails' table for customer_id: {customer_id}, bill_month_1: {bill_month_1}, bill_month_2: {bill_month_2}, bill_paid_1: {bill_paid_1}, bill_paid_2: {bill_paid_2}")
                try:
                    cur.execute(insert_query, (customer_id, secret_key, bill_month_1, service_plan, monthly_charge,
                                                data_usage, overage_charges, taxes, total_amount,
                                                monthly_data_allowed_download, monthly_data_allowed_upload,
                                                allowed_upload_speed, allowed_download_speed, bill_paid_1))
                    cur.execute(insert_query, (customer_id, secret_key, bill_month_2, service_plan, monthly_charge,
                                                data_usage, overage_charges, taxes, total_amount,
                                                monthly_data_allowed_download, monthly_data_allowed_upload,
                                                allowed_upload_speed, allowed_download_speed, bill_paid_2))
                except Exception as e:
                    logger.error(f"Error inserting data into 'customerbillingdetails' table for customer_id: {customer_id}, bill_month_1: {bill_month_1}, bill_month_2: {bill_month_2}, error: {e}")
            conn.commit()
            logger.info("Data inserted into 'customerbillingdetails' table successfully.")

            # Insert data into 'customercurrentmonth' table
            current_month = date(2024, 9, 1)
            for customer in customer_data:
                customer_id = customer['customer_id']
                secret_key = customer['secret_key']
                current_total_download = 500  # 500GB
                current_total_upload = 50  # 50GB
                monthly_data_allowed_download = 1000  # 1TB
                monthly_data_allowed_upload = 100  # 100GB
                allowed_upload_speed = 50
                allowed_download_speed = 500

                if customer_id < 2000000005:
                    new_upload_speed = 50
                    new_download_speed = 500
                else:
                    new_upload_speed = 10
                    new_download_speed = 50

                insert_query = """
                    INSERT INTO customercurrentmonth (customer_id, current_month, secret_key, current_total_download,
                                                      current_total_upload, monthly_data_allowed_download,
                                                      monthly_data_allowed_upload, allowed_upload_speed,
                                                      allowed_download_speed, new_upload_speed, new_download_speed)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                """
                logger.info(f"Inserting data into 'customercurrentmonth' table for customer_id: {customer_id}, current_month: {current_month}, new_upload_speed: {new_upload_speed}, new_download_speed: {new_download_speed}")
                try:
                    cur.execute(insert_query, (customer_id, current_month, secret_key, current_total_download,
                                               current_total_upload, monthly_data_allowed_download,
                                               monthly_data_allowed_upload, allowed_upload_speed,
                                               allowed_download_speed, new_upload_speed, new_download_speed))
                except Exception as e:
                    logger.error(f"Error inserting data into 'customercurrentmonth' table for customer_id: {customer_id}, current_month: {current_month}, error: {e}")
            conn.commit()
            logger.info("Data inserted into 'customercurrentmonth' table successfully.")

            # Insert data into 'customermodemdetails' table
            for customer in customer_data:
                customer_id = customer['customer_id']
                node_id = customer['node_id']
                modem_serial_number = customer['modem_serial_number']
                modem_model = 'Model X'
                modem_manufacturer = 'Acme Inc.'
                modem_ip = customer['modem_ip']
                modem_firmware_version = '1.2.3'
                modem_activation_date = date(2023, 1, 1)
                modem_status = True
                modem_notes = 'No notes'

                insert_query = """
                    INSERT INTO customermodemdetails (customer_id, node_id, modem_serial_number, modem_model,
                                                      modem_manufacturer, modem_ip, modem_firmware_version,
                                                      modem_activation_date, modem_status, modem_notes)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                """
                logger.info(f"Inserting data into 'customermodemdetails' table for customer_id: {customer_id}, node_id: {node_id}, modem_serial_number: {modem_serial_number}, modem_ip: {modem_ip}")
                try:
                    cur.execute(insert_query, (customer_id, node_id, modem_serial_number, modem_model,
                                                modem_manufacturer, modem_ip, modem_firmware_version,
                                                modem_activation_date, modem_status, modem_notes))
                except Exception as e:
                    logger.error(f"Error inserting data into 'customermodemdetails' table for customer_id: {customer_id}, node_id: {node_id}, modem_serial_number: {modem_serial_number}, error: {e}")
            conn.commit()
            logger.info("Data inserted into 'customermodemdetails' table successfully.")

            # Insert data into 'nodedetails' table
            zip_codes = [10001, 10005, 10009, 10018]
            for customer in customer_data:
                node_id = customer['node_id']
                node_name = f'Node {node_id - 4000000000}'
                node_location_city = 'New York'
                node_location_state = 'NY'
                node_location_zipcode = random.choice(zip_codes)  # Randomly pick a zip code
                node_status = False if node_id < 4000000005 else True
                node_next_maintenance_date = None

                insert_query = """
                    INSERT INTO nodedetails (node_id, node_name, node_location_city, node_location_state,
                                             node_location_zipcode, node_status, node_next_maintenance_date)
                    VALUES (%s, %s, %s, %s, %s, %s, %s)
                """
                logger.info(f"Inserting data into 'nodedetails' table for node_id: {node_id}, node_status: {node_status}, zip_code: {node_location_zipcode}")
                try:
                    cur.execute(insert_query, (node_id, node_name, node_location_city, node_location_state,
                                                node_location_zipcode, node_status, node_next_maintenance_date))
                except Exception as e:
                    logger.error(f"Error inserting data into 'nodedetails' table for node_id: {node_id}, error: {e}")
            conn.commit()
            logger.info("Data inserted into 'nodedetails' table successfully.")

        conn.close()

        return {
            'statusCode': 200,
            'body': 'Data insertion successful'
        }

    except Exception as e:
        logger.error(f"Error: {e}")
        return {
            'statusCode': 500,
            'body': 'Error occurred during data insertion'
        }