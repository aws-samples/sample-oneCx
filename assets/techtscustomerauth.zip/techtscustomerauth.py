import pymysql
import logging
import boto3
import json

# Set up logging to CloudWatch
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    try:
        # Get RDS host from Parameter Store
        ssm_client = boto3.client('ssm')
        RDS_INSTANCE_ENDPOINT = ssm_client.get_parameter(Name='/ccj/RDS/TechsupportDBEndpoint')['Parameter']['Value']

        # Get RDS password from Secrets Manager
        secrets_client = boto3.client('secretsmanager')
        secret_response = secrets_client.get_secret_value(SecretId='ccj-techsupport-db-secret')
        secret = json.loads(secret_response['SecretString'])
        DATABASE_PASSWORD = secret['password']

        rds_user = 'admin'
        rds_database = 'techsupport'

        # Parse customer_id and secret_key from the event payload
        customer_id = None
        secret_key = None
        for param in event.get('parameters', []):
            if param['name'] == 'customer_id':
                customer_id = param['value']
            elif param['name'] == 'secret_key':
                secret_key = param['value']

        # Validate customer_id and secret_key
        if not customer_id or len(customer_id) != 10:
            return send_reprompt_response(event, "Please provide a 10-digit customer_id.")
        if not secret_key or len(secret_key) != 6:
            return send_reprompt_response(event, "Please provide a 6-digit secret_key.")

        logger.info(f"customer_id: {customer_id}, secret_key: {secret_key}")

        # Connect to the RDS instance
        logger.info("Connecting to RDS instance...")
        conn = pymysql.connect(
            host=RDS_INSTANCE_ENDPOINT,
            user=rds_user,
            password=DATABASE_PASSWORD,
            connect_timeout=5
        )

        with conn.cursor() as cur:
            # Create the database if it doesn't exist
            cur.execute(f"CREATE DATABASE IF NOT EXISTS {rds_database}")
            conn.commit()

            # Switch to the techsupport database
            cur.execute(f"USE {rds_database}")

            # Verify customer_id and secret_key
            verify_query = """
                SELECT COUNT(*) AS count
                FROM customerauth
                WHERE customer_id = %s AND secret_key = %s;
            """
            logger.info("Executing verify_query with customer_id: %s, secret_key: %s", customer_id, secret_key)
            cur.execute(verify_query, (customer_id, secret_key))
            result = cur.fetchone()

            if result is None or result[0] == 0:
                logger.error("Invalid customer_id or secret_key")
                return send_reprompt_response(event, "Invalid customer_id or secret_key. Please provide a valid 10-digit customer_id and 6-digit secret_key.")

            return send_success_response(event, f"Customer with ID {customer_id} authenticated successfully.")

        conn.close()

    except Exception as e:
        logger.error(f"Error: {e}")
        return send_failure_response(event, "Error occurred while processing the request.")

def send_success_response(event, response_body):
    return build_response(event, response_body, "REPROMPT")

def send_reprompt_response(event, message):
    agent = event['agent']
    actionGroup = event['actionGroup']
    function = event['function']
    parameters = event.get('parameters', [])
    response_body = {
        'TEXT': {
            'body': message
        }
    }
    function_response = {
        'actionGroup': actionGroup,
        'function': function,
        'functionResponse': {
            'responseState': "REPROMPT",
            'responseBody': response_body
        }
    }
    session_attributes = event.get('sessionAttributes', {})
    prompt_session_attributes = event.get('promptSessionAttributes', {})
    action_response = {
        'messageVersion': '1.0',
        'response': function_response,
        'sessionAttributes': session_attributes,
        'promptSessionAttributes': prompt_session_attributes
    }
    return action_response

def send_failure_response(event, message):
    agent = event['agent']
    actionGroup = event['actionGroup']
    function = event['function']
    parameters = event.get('parameters', [])
    response_body = {
        'TEXT': {
            'body': message
        }
    }
    function_response = {
        'actionGroup': actionGroup,
        'function': function,
        'functionResponse': {
            'responseState': "FAILURE",
            'responseBody': response_body
        }
    }
    session_attributes = event.get('sessionAttributes', {})
    prompt_session_attributes = event.get('promptSessionAttributes', {})
    action_response = {
        'messageVersion': '1.0',
        'response': function_response,
        'sessionAttributes': session_attributes,
        'promptSessionAttributes': prompt_session_attributes
    }
    return action_response

def build_response(event, response_body, response_state):
    agent = event['agent']
    actionGroup = event['actionGroup']
    function = event['function']
    parameters = event.get('parameters', [])

    response_body = {
        'TEXT': {
            'body': response_body
        }
    }

    function_response = {
        'actionGroup': actionGroup,
        'function': function,
        'functionResponse': {
            'responseState': response_state,
            'responseBody': response_body
        }
    }

    session_attributes = event.get('sessionAttributes', {})
    prompt_session_attributes = event.get('promptSessionAttributes', {})

    action_response = {
        'messageVersion': '1.0',
        'response': function_response,
        'sessionAttributes': session_attributes,
        'promptSessionAttributes': prompt_session_attributes
    }

    return action_response