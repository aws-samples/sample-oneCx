import mysql.connector
import logging
from datetime import date, datetime
import boto3
import json

# Set up logging to CloudWatch
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    try:
        # Get RDS host from Parameter Store
        ssm_client = boto3.client('ssm')
        RDS_INSTANCE_ENDPOINT = ssm_client.get_parameter(Name='/ccj/RDS/TechsupportDBEndpoint')['Parameter']['Value']

        # Get RDS password from Secrets Manager
        secrets_client = boto3.client('secretsmanager')
        secret_response = secrets_client.get_secret_value(SecretId='ccj-techsupport-db-secret')
        secret = json.loads(secret_response['SecretString'])
        DATABASE_PASSWORD = secret['password']

        rds_user = 'admin'
        rds_database = 'techsupport'

        # Parse customer_id from the event
        customer_id = None
        for param in event.get('parameters', []):
            if param['name'] == 'customer_id':
                customer_id = param['value']

        if not customer_id:
            logger.error("Missing customer_id in the event payload")
            return build_response(event, "Missing customer_id in the event payload", "FAILURE")

        logger.info(f"Received customer_id: {customer_id}")

        # Set the current month to September 2024
        current_month = date(2024, 9, 1)

        # Connect to the RDS instance
        logger.info("Connecting to RDS instance...")
        conn = mysql.connector.connect(
            host=RDS_INSTANCE_ENDPOINT,
            user=rds_user,
            password=DATABASE_PASSWORD,
            database=rds_database
        )

        with conn.cursor() as cur:
            # Find the allowed_upload_speed, allowed_download_speed, new_upload_speed, and new_download_speed
            query = """
                SELECT allowed_upload_speed, allowed_download_speed, new_upload_speed, new_download_speed
                FROM customercurrentmonth
                WHERE customer_id = %s AND current_month = %s;
            """
            logger.info(f"Executing query with customer_id: {customer_id}, current_month: {current_month}")
            cur.execute(query, (customer_id, current_month))
            result = cur.fetchone()

            if result:
                allowed_upload_speed, allowed_download_speed, new_upload_speed, new_download_speed = result
                logger.info(f"Retrieved data: allowed_upload_speed={allowed_upload_speed}, allowed_download_speed={allowed_download_speed}, new_upload_speed={new_upload_speed}, new_download_speed={new_download_speed}")
                response_body = f"Customer with ID {customer_id} has allowed_upload_speed={allowed_upload_speed}, allowed_download_speed={allowed_download_speed}, new_upload_speed={new_upload_speed}, new_download_speed={new_download_speed}"
                return build_response(event, response_body, "REPROMPT")
            else:
                logger.error("No data found for the given customer_id and current_month")
                return build_response(event, "No data found for the given customer_id and current_month", "FAILURE")

        conn.close()

    except Exception as e:
        logger.error(f"Error: {e}")
        return build_response(event, "Error occurred while processing the request", "FAILURE")

def build_response(event, response_body, response_state):
    agent = event['agent']
    actionGroup = event['actionGroup']
    function = event['function']
    parameters = event.get('parameters', [])

    response_body = {
        'TEXT': {
            'body': response_body
        }
    }

    function_response = {
        'actionGroup': actionGroup,
        'function': function,
        'functionResponse': {
            'responseState': response_state,
            'responseBody': response_body
        }
    }

    session_attributes = event.get('sessionAttributes', {})
    prompt_session_attributes = event.get('promptSessionAttributes', {})

    action_response = {
        'messageVersion': '1.0',
        'response': function_response,
        'sessionAttributes': session_attributes,
        'promptSessionAttributes': prompt_session_attributes
    }

    return action_response